package cl.duoc.prestaaula.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Perfiles del caso: docente, encargado CRA y jefatura (Jefe UTP y Jefe de Administración y Finanzas). */
enum class Perfil(val etiqueta: String) {
    DOCENTE("Docente"),
    ENCARGADO_CRA("Encargado CRA"),
    JEFATURA("Jefatura (UTP / Administración y Finanzas)")
}

enum class EstadoEquipo(val etiqueta: String) {
    DISPONIBLE("Disponible"),
    PRESTADO("Prestado"),
    MANTENCION("En mantención")
}

// CICLO DE VIDA de un préstamo:
//   RESERVADO -> RETIRADO -> DEVUELTO   (el docente reserva, el CRA entrega y luego recibe)
//   RESERVADO -> CANCELADO
// Solo RESERVADO y RETIRADO "bloquean" el horario (ver `activo()` en el ViewModel).
enum class EstadoPrestamo(val etiqueta: String) {
    RESERVADO("Reservado"),
    RETIRADO("Retirado"),
    DEVUELTO("Devuelto"),
    CANCELADO("Cancelado")
}

enum class EstadoDevolucion(val etiqueta: String) {
    BUEN_ESTADO("Buen estado"),
    CON_DANO("Con daño (ej. pantalla trizada)"),
    ACCESORIO_FALTANTE("Accesorio faltante (ej. cargador)")
}

/** Tabla usuarios: personal del colegio que puede iniciar sesión. */
@Entity(tableName = "usuarios", indices = [Index(value = ["correo"], unique = true)])
data class Usuario(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nombre: String,
    val correo: String,
    // OJO: se guarda en texto plano por ser proyecto académico (en producción iría con hash).
    val clave: String,
    // El perfil define los permisos: qué pestañas y botones ve cada usuario.
    val perfil: Perfil
)

/** Tabla equipos (inventario): tipo, marca, número de identificación interno y estado. */
@Entity(tableName = "equipos")
data class Equipo(
    // ID interno legible (ej. "NB-001"). No es autogenerado: lo escribe el encargado CRA.
    @PrimaryKey val id: String,
    val tipo: String,
    val marca: String,
    val estado: EstadoEquipo = EstadoEquipo.DISPONIBLE
)

/** Tabla prestamos: equipo, docente responsable, curso, fecha, retiro/devolución y observaciones. */
@Entity(tableName = "prestamos")
data class Prestamo(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    // Referencia lógica al equipo (guarda su ID; no se declaró @ForeignKey).
    val equipoId: String,
    // Nombre del docente responsable (tomado de la sesión al reservar).
    val docente: String,
    val curso: String,
    // Fecha como texto "dd/MM/yyyy" y bloque como texto de la lista BLOQUES.
    val fecha: String,
    val bloque: String,
    val estado: EstadoPrestamo = EstadoPrestamo.RESERVADO,
    // Los campos con `?` son opcionales: quedan en null hasta que ocurre el retiro / la devolución.
    val horaRetiro: String? = null,
    val horaDevolucion: String? = null,
    val estadoDevolucion: EstadoDevolucion? = null,
    val observaciones: String = ""
)

val TIPOS_EQUIPO = listOf("Notebook", "Tablet", "Proyector", "Cable HDMI", "Otro")

val BLOQUES = listOf(
    "Bloque 1 · 08:00 - 08:45",
    "Bloque 2 · 08:45 - 09:30",
    "Bloque 3 · 09:45 - 10:30",
    "Bloque 4 · 10:30 - 11:15",
    "Bloque 5 · 11:30 - 12:15",
    "Bloque 6 · 12:15 - 13:00",
    "Bloque 7 · 14:00 - 14:45",
    "Bloque 8 · 14:45 - 15:30"
)

/** Curso existente del colegio. [codigo] es lo que se guarda ("7°A"); [etiqueta] es lo que se muestra. */
data class Curso(val codigo: String, val etiqueta: String, val grupo: String)

/** Cursos disponibles en la reserva (1° a 8° Básico, paralelos A a C). Para agregar o quitar cursos, editar aquí. */
val CURSOS: List<Curso> = (1..8).flatMap { n ->
    listOf("A", "B", "C").map { letra -> Curso("$n°$letra", "$n° Básico $letra", "$n° Básico") }
}
