package cl.duoc.prestaaula.ui

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.ui.graphics.vector.ImageVector

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.PaddingValues
import cl.duoc.prestaaula.model.EstadoDevolucion
import cl.duoc.prestaaula.model.EstadoEquipo
import cl.duoc.prestaaula.model.EstadoPrestamo
import cl.duoc.prestaaula.viewmodel.PrestaAulaViewModel

/** Pantalla 6: reportes de uso y de equipos con incidencias frecuentes (CRA, UTP y Administración). */
@Composable
fun ReportesScreen(vm: PrestaAulaViewModel) {
    val tema = temaDePerfil(vm.usuario?.perfil)

    // Cuenta equipos por estado (3 tarjetas de arriba). Triple = (disponibles, prestados, mantención).
    val resumen by remember {
        derivedStateOf {
            Triple(
                vm.equipos.count { it.estado == EstadoEquipo.DISPONIBLE },
                vm.equipos.count { it.estado == EstadoEquipo.PRESTADO },
                vm.equipos.count { it.estado == EstadoEquipo.MANTENCION }
            )
        }
    }

    // USO POR TIPO: ignora cancelados, agrupa por tipo de equipo (groupBy), cuenta y ordena de mayor a menor.
    val usoPorTipo by remember {
        derivedStateOf {
            vm.prestamos
                .filter { it.estado != EstadoPrestamo.CANCELADO }
                .groupBy { p -> vm.equipos.firstOrNull { it.id == p.equipoId }?.tipo ?: "Otro" }
                .map { (tipo, l) -> tipo to l.size }
                .sortedByDescending { it.second }
        }
    }

    // INCIDENCIAS: préstamos devueltos con daño o accesorio faltante, agrupados por equipo.
    val incidencias by remember {
        derivedStateOf {
            vm.prestamos
                .filter { it.estadoDevolucion != null && it.estadoDevolucion != EstadoDevolucion.BUEN_ESTADO }
                .groupBy { it.equipoId }
                .map { (id, l) -> id to l.size }
                .sortedByDescending { it.second }
        }
    }

    // El mayor valor sirve para calcular el largo de cada barra (cantidad / maxUso).
    val maxUso = (usoPorTipo.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            EncabezadoPantalla(
                icono = Icons.Rounded.BarChart,
                titulo = "Reportes",
                tema = tema,
                subtitulo = "Uso de recursos e incidencias"
            )
        }

        // Estado del inventario: tres tarjetas con número grande
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TarjetaNumero(
                    icono = Icons.Rounded.CheckCircle, valor = resumen.first, etiqueta = "Disponibles",
                    color = colorEstadoEquipo(EstadoEquipo.DISPONIBLE),
                    modifier = Modifier.weight(1f)
                )
                TarjetaNumero(
                    icono = Icons.Rounded.SwapHoriz, valor = resumen.second, etiqueta = "Prestados",
                    color = colorEstadoEquipo(EstadoEquipo.PRESTADO),
                    modifier = Modifier.weight(1f)
                )
                TarjetaNumero(
                    icono = Icons.Rounded.Build, valor = resumen.third, etiqueta = "Mantención",
                    color = colorEstadoEquipo(EstadoEquipo.MANTENCION),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Uso por tipo de equipo: barras de progreso
        item { TituloSeccion("Uso por tipo de equipo") }
        item {
            TarjetaVidrio {
                if (usoPorTipo.isEmpty()) {
                    Text("Sin préstamos registrados.", color = TextoSuave, fontSize = 14.sp)
                }
                usoPorTipo.forEach { (tipo, n) ->
                    FilaUso(
                        tipo = tipo,
                        cantidad = n,
                        fraccion = n.toFloat() / maxUso,
                        tema = tema
                    )
                }
            }
        }

        // Equipos con incidencias
        item { TituloSeccion("Equipos con incidencias") }
        item {
            TarjetaVidrio {
                if (incidencias.isEmpty()) {
                    Text("Sin incidencias registradas.", color = TextoSuave, fontSize = 14.sp)
                }
                incidencias.forEach { (id, n) ->
                    val eq = vm.equipos.firstOrNull { it.id == id }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Warning,
                            contentDescription = null,
                            tint = Color(0xFFFF8A80),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "$id ${eq?.tipo.orEmpty()} ${eq?.marca.orEmpty()}",
                            color = Color.White,
                            fontSize = 14.sp,
                            modifier = Modifier.weight(1f)
                        )
                        EtiquetaEstado("$n incidencia(s)", Color(0xFFFF8A80))
                    }
                }
            }
        }
    }
}

@Composable
private fun TarjetaNumero(
    icono: ImageVector,
    valor: Int,
    etiqueta: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    val forma = RoundedCornerShape(20.dp)
    Column(
        modifier = modifier
            .clip(forma)
            .background(Brush.verticalGradient(listOf(color.copy(alpha = 0.30f), color.copy(alpha = 0.10f))))
            .border(1.dp, color.copy(alpha = 0.5f), forma)
            .padding(vertical = 14.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Icon(imageVector = icono, contentDescription = null, tint = color, modifier = Modifier.size(26.dp))
        Text("$valor", color = color, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Text(etiqueta, color = TextoSuave, fontSize = 12.sp)
    }
}

@Composable
private fun FilaUso(tipo: String, cantidad: Int, fraccion: Float, tema: TemaPerfil) {
    Column(
        modifier = Modifier.padding(bottom = 8.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = iconoDeTipo(tipo),
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                tipo,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
            Text("$cantidad préstamo(s)", color = TextoSuave, fontSize = 13.sp)
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(50))
                .background(Color(0x22FFFFFF))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(fraccion.coerceIn(0.03f, 1f))
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(listOf(tema.colorA, tema.colorB)))
            )
        }
    }
}
