package cl.duoc.prestaaula.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Computer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cl.duoc.prestaaula.model.Equipo
import cl.duoc.prestaaula.model.Perfil
import cl.duoc.prestaaula.model.TIPOS_EQUIPO
import cl.duoc.prestaaula.viewmodel.PrestaAulaViewModel

/**
 * Pantalla 2: inventario y disponibilidad en tiempo real.
 * Las categorías están en un menú desplegable y las tarjetas son compactas y se acomodan en una
 * cuadrícula adaptable: en el celular caben 2 por fila y en pantallas anchas (computador/tablet) más.
 */
@Composable
fun InventarioScreen(
    vm: PrestaAulaViewModel,
    onEquipo: (String) -> Unit,
    mostrarMensaje: (String) -> Unit
) {
    var filtro by rememberSaveable { mutableStateOf("Todos") }
    var mostrarDialogo by rememberSaveable { mutableStateOf(false) }
    val visibles by remember {
        derivedStateOf {
            if (filtro == "Todos") vm.equipos.toList() else vm.equipos.filter { it.tipo == filtro }
        }
    }
    val perfil = vm.usuario?.perfil
    val esCra = perfil == Perfil.ENCARGADO_CRA
    val tema = temaDePerfil(perfil)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Spacer(Modifier.height(4.dp))

        EncabezadoPantalla(
            icono = Icons.Rounded.Computer,
            titulo = "Disponibilidad de recursos",
            tema = tema,
            subtitulo = "${visibles.size} equipo(s)"
        )

        Row(
            modifier = Modifier.padding(top = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CampoDesplegable(
                etiqueta = "Categoría",
                valor = filtro,
                opciones = listOf("Todos") + TIPOS_EQUIPO,
                acento = tema.colorB,
                modifier = Modifier.weight(1f),
                onSeleccion = { filtro = it }
            )
            if (esCra) {
                BotonPrestaAula(
                    texto = "＋ Agregar",
                    tema = tema,
                    onClick = { mostrarDialogo = true }
                )
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 140.dp),
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(visibles, key = { it.id }) { eq ->
                TarjetaEquipo(eq = eq, onClick = { onEquipo(eq.id) })
            }
        }
    }

    if (mostrarDialogo) {
        AgregarEquipoDialog(
            tema = tema,
            onCancelar = { mostrarDialogo = false },
            onGuardar = { id, tipo, marca ->
                val error = vm.agregarEquipo(id, tipo, marca)
                if (error == null) {
                    mostrarDialogo = false
                    mostrarMensaje("Equipo agregado")
                } else mostrarMensaje(error)
            }
        )
    }
}

/** Tarjeta compacta: icono + estado arriba, nombre y ID abajo. */
@Composable
private fun TarjetaEquipo(eq: Equipo, onClick: () -> Unit) {
    val color = colorEstadoEquipo(eq.estado)
    TarjetaVidrio(
        franja = Brush.verticalGradient(listOf(color, color.copy(alpha = 0.4f))),
        relleno = 10.dp,
        onClick = onClick
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconoCircular(icono = iconoDeTipo(eq.tipo), tamano = 32.dp)
            Spacer(Modifier.weight(1f))
            EtiquetaEstado(eq.estado.etiqueta, color, compacta = true)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "${eq.tipo} ${eq.marca}",
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            "ID ${eq.id}",
            color = TextoSuave,
            fontSize = 11.sp,
            maxLines = 1
        )
    }
}

@Composable
private fun AgregarEquipoDialog(
    tema: TemaPerfil,
    onCancelar: () -> Unit,
    onGuardar: (id: String, tipo: String, marca: String) -> Unit
) {
    var id by rememberSaveable { mutableStateOf("") }
    var marca by rememberSaveable { mutableStateOf("") }
    var tipo by rememberSaveable { mutableStateOf(TIPOS_EQUIPO.first()) }
    val campos = coloresCampo(tema.colorB)

    AlertDialog(
        onDismissRequest = onCancelar,
        containerColor = ColorDialogo,
        titleContentColor = Color.White,
        textContentColor = Color.White,
        shape = RoundedCornerShape(24.dp),
        title = { Text("Nuevo equipo", fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = id,
                    onValueChange = { id = it },
                    label = { Text("ID interno (ej. NB-003)") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = campos
                )
                OutlinedTextField(
                    value = marca,
                    onValueChange = { marca = it },
                    label = { Text("Marca") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = campos
                )
                CampoDesplegable(
                    etiqueta = "Tipo de equipo",
                    valor = tipo,
                    opciones = TIPOS_EQUIPO,
                    acento = tema.colorB,
                    onSeleccion = { tipo = it }
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onGuardar(id, tipo, marca) },
                colors = ButtonDefaults.textButtonColors(contentColor = ColorBotonDialogo)
            ) { Text("Guardar", fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(
                onClick = onCancelar,
                colors = ButtonDefaults.textButtonColors(contentColor = Color(0xB3FFFFFF))
            ) { Text("Cancelar") }
        }
    )
}
