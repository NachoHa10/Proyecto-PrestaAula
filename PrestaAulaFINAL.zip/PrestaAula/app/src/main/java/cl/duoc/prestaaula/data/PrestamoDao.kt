package cl.duoc.prestaaula.data

import androidx.room.*
import cl.duoc.prestaaula.model.Prestamo
import kotlinx.coroutines.flow.Flow

@Dao
interface PrestamoDao {
    @Query("SELECT * FROM prestamos ORDER BY id DESC")
    // Los más nuevos primero (ORDER BY id DESC). También es un Flow reactivo.
    fun observarTodos(): Flow<List<Prestamo>>

    @Query("SELECT * FROM prestamos WHERE equipoId = :equipoId ORDER BY id DESC")
    // Consulta con parámetro (:equipoId). Historial de un equipo específico.
    fun observarPorEquipo(equipoId: String): Flow<List<Prestamo>>

    @Insert
    // suspend = corre fuera del hilo principal (se llama desde una corrutina).
    suspend fun insertar(prestamo: Prestamo)

    @Update
    suspend fun actualizar(prestamo: Prestamo)
}
