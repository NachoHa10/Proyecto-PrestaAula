package cl.duoc.prestaaula

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import cl.duoc.prestaaula.navigation.PrestaAulaApp
import cl.duoc.prestaaula.ui.PrestaAulaTheme
import cl.duoc.prestaaula.viewmodel.PrestaAulaViewModel

class MainActivity : ComponentActivity() {
    // UNA sola Activity: toda la app es Compose.
    // `by viewModels()` crea el ViewModel y lo conserva al rotar la pantalla
    // (si no, se perderían la sesión y los datos en memoria).
    private val vm: PrestaAulaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // setContent reemplaza al XML: aquí parte el árbol de Composables.
        // PrestaAulaTheme aplica el tema oscuro y PrestaAulaApp contiene navegación + pantallas.
        setContent {
            PrestaAulaTheme {
                PrestaAulaApp(vm)
            }
        }
    }
}
