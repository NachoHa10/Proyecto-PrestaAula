package cl.duoc.prestaaula.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cl.duoc.prestaaula.model.BLOQUES
import cl.duoc.prestaaula.model.CURSOS
import cl.duoc.prestaaula.model.EstadoEquipo
import cl.duoc.prestaaula.viewmodel.PrestaAulaViewModel
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter

private val Libre = Color(0xFF69F0AE)
private val Ocupado = Color(0xFFFF8A80)
private val Aviso = Color(0xFFFFD740)

/**
 * Pantalla 4: reserva en 3 pasos. 1) curso (menú desplegable, no se escribe), 2) día en un
 * calendario real, 3) horario libre. Los bloques ocupados no se pueden elegir.
 */
@Composable
fun ReservarScreen(
    vm: PrestaAulaViewModel,
    equipoId: String,
    onListo: () -> Unit,
    mostrarMensaje: (String) -> Unit
) {
    val hoy = remember { LocalDate.now() }
    val formato = remember { DateTimeFormatter.ofPattern("dd/MM/yyyy") }

    // Estado de la reserva en 3 pasos. rememberSaveable lo conserva al rotar.
    // - diaEpoch: el día guardado como Long (-1 = ninguno), porque LocalDate no se guarda directo.
    // - bloqueIdx: posición dentro de BLOQUES (-1 = ninguno).
    var cursoSel by rememberSaveable { mutableStateOf("") }
    var mesOffset by rememberSaveable { mutableIntStateOf(0) }
    var diaEpoch by rememberSaveable { mutableStateOf(-1L) }
    var bloqueIdx by rememberSaveable { mutableIntStateOf(-1) }

    val docente = vm.usuario?.nombre.orEmpty()
    val equipo = vm.equipos.firstOrNull { it.id == equipoId }
    val tema = temaDePerfil(vm.usuario?.perfil)

    val mes = YearMonth.from(hoy).plusMonths(mesOffset.toLong())
    val dia: LocalDate? = if (diaEpoch >= 0L) LocalDate.ofEpochDay(diaEpoch) else null
    val fecha: String? = dia?.format(formato)
    val cursoEtiqueta = CURSOS.firstOrNull { it.codigo == cursoSel }?.etiqueta

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            EncabezadoPantalla(
                icono = Icons.Rounded.CalendarMonth,
                titulo = "Reservar ${equipo?.tipo.orEmpty()} ${equipo?.marca.orEmpty()}",
                tema = tema,
                subtitulo = "ID $equipoId · $docente"
            )

            // 1. Curso: menú desplegable con los cursos existentes (no se puede escribir).
            TituloSeccion("1. ¿Para qué curso?")
            CampoDesplegableBase(
                etiqueta = "Curso",
                texto = cursoEtiqueta ?: "Selecciona el curso…",
                acento = tema.colorB
            ) { cerrar ->
                CURSOS.groupBy { it.grupo }.forEach { (grupo, cursos) ->
                    Text(
                        grupo,
                        color = ColorBotonDialogo,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                    cursos.forEach { c ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    c.etiqueta,
                                    fontWeight = if (c.codigo == cursoSel) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            onClick = {
                                cursoSel = c.codigo
                                cerrar()
                            }
                        )
                    }
                }
            }

            // 2. Día: calendario real.
            TituloSeccion("2. Elige el día")
            Text(
                "Punto rojo: el equipo ya tiene horarios ocupados ese día. No se reserva en fines de semana.",
                color = TextoSuave,
                fontSize = 12.sp
            )
            CalendarioReserva(
                mes = mes,
                hoy = hoy,
                seleccionado = dia,
                acento = tema.colorA,
                tieneReservas = { vm.tieneReservas(equipoId, it.format(formato)) },
                onMesAnterior = { mesOffset -= 1 },
                onMesSiguiente = { mesOffset += 1 },
                // Al cambiar de día se limpia el bloque elegido (los horarios libres son distintos cada día).
                onSeleccionar = {
                    diaEpoch = it.toEpochDay()
                    bloqueIdx = -1
                }
            )

            // 3. Horario.
            TituloSeccion("3. Elige un horario libre")
            if (fecha == null) {
                Text(
                    "Elige primero un día en el calendario.",
                    color = TextoSuave,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                BLOQUES.forEachIndexed { i, bloque ->
                    val reserva = vm.reservaActiva(equipoId, fecha, bloque)
                    val enMantencion = equipo?.estado == EstadoEquipo.MANTENCION
                    val yoOcupado = vm.docenteOcupado(docente, fecha, bloque)
                    val elegido = bloqueIdx == i

                    // Para cada bloque se calcula su estado visible:
                    // Ocupado (por otro docente) > En mantención > Ya tienes otra reserva > Elegido > Libre.
                    val estado: String
                    val colorEstado: Color
                    when {
                        reserva != null -> {
                            estado = if (reserva.docente == docente) "Ya lo reservaste" else "Ocupado por ${reserva.docente}"
                            colorEstado = Ocupado
                        }
                        enMantencion -> {
                            estado = "En mantención"
                            colorEstado = Ocupado
                        }
                        yoOcupado -> {
                            estado = "Ya tienes otra reserva"
                            colorEstado = Aviso
                        }
                        elegido -> {
                            estado = "Elegido"
                            colorEstado = Color.White
                        }
                        else -> {
                            estado = "Libre"
                            colorEstado = Libre
                        }
                    }
                    // Solo se pueden tocar los bloques realmente libres.
                    val habilitado = reserva == null && !enMantencion && !yoOcupado

                    FilaBloque(
                        titulo = bloque,
                        estado = estado,
                        colorEstado = colorEstado,
                        seleccionado = elegido,
                        habilitado = habilitado,
                        acento = tema.colorA,
                        onClick = { bloqueIdx = i }
                    )
                }
            }

            BotonPrestaAula(
                texto = "Confirmar reserva",
                tema = tema,
                // El botón se activa solo cuando los 3 pasos están completos.
                habilitado = cursoSel.isNotBlank() && fecha != null && bloqueIdx >= 0,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    if (fecha != null && bloqueIdx >= 0) {
                        // reservar() devuelve null si salió bien o el mensaje de error; se muestra en el Snackbar.
                        val error = vm.reservar(equipoId, cursoSel, fecha, BLOQUES[bloqueIdx])
                        if (error == null) {
                            mostrarMensaje("Reserva confirmada")
                            onListo()
                        } else mostrarMensaje(error)
                    }
                }
            )
        }
    }
}

@Composable
private fun FilaBloque(
    titulo: String,
    estado: String,
    colorEstado: Color,
    seleccionado: Boolean,
    habilitado: Boolean,
    acento: Color,
    onClick: () -> Unit
) {
    val forma = RoundedCornerShape(14.dp)
    val fondo = when {
        seleccionado -> acento.copy(alpha = 0.85f)
        !habilitado -> colorEstado.copy(alpha = 0.10f)
        else -> Color(0x14FFFFFF)
    }
    val borde = when {
        seleccionado -> Color.Transparent
        !habilitado -> colorEstado.copy(alpha = 0.5f)
        else -> Color(0x44FFFFFF)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(forma)
            .background(fondo)
            .border(1.dp, borde, forma)
            .clickable(enabled = habilitado, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            titulo,
            color = if (habilitado || seleccionado) Color.White else Color(0x99FFFFFF),
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
        Text(
            estado,
            color = if (seleccionado) Color.White else colorEstado,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
