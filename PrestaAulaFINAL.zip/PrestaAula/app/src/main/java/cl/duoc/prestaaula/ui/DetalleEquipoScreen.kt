package cl.duoc.prestaaula.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cl.duoc.prestaaula.model.EstadoEquipo
import cl.duoc.prestaaula.model.EstadoPrestamo
import cl.duoc.prestaaula.model.Perfil
import cl.duoc.prestaaula.viewmodel.PrestaAulaViewModel

/** Pantalla 3: detalle del equipo (recibe el ID como argumento), responsable y historial. */
@Composable
fun DetalleEquipoScreen(
    vm: PrestaAulaViewModel,
    equipoId: String,
    onReservar: () -> Unit,
    onVolver: () -> Unit
) {
    val equipo = vm.equipos.firstOrNull { it.id == equipoId }
    val historial = vm.historialDe(equipoId)
    val perfil = vm.usuario?.perfil
    val tema = temaDePerfil(perfil)

    if (equipo == null) {
        Column(Modifier.padding(16.dp)) {
            TarjetaVidrio {
                Text("Equipo no encontrado", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                BotonContorno(texto = "Volver", onClick = onVolver, modifier = Modifier.fillMaxWidth())
            }
        }
        return
    }

    val ultimoResponsable = historial.firstOrNull {
        it.estado == EstadoPrestamo.RETIRADO || it.estado == EstadoPrestamo.DEVUELTO
    }?.docente
    val colorEstado = colorEstadoEquipo(equipo.estado)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            EncabezadoPantalla(
                icono = iconoDeTipo(equipo.tipo),
                titulo = "${equipo.tipo} ${equipo.marca}",
                tema = tema,
                subtitulo = "Detalle del equipo"
            )
        }

        item {
            TarjetaVidrio(
                franja = Brush.verticalGradient(listOf(colorEstado, colorEstado.copy(alpha = 0.4f)))
            ) {
                Dato("ID interno", equipo.id)
                Spacer(Modifier.height(8.dp))
                Text("Estado actual", color = TextoSuave, fontSize = 12.sp)
                EtiquetaEstado(equipo.estado.etiqueta, colorEstado)
                Spacer(Modifier.height(8.dp))
                Dato("Último responsable", ultimoResponsable ?: "Sin registros")
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (perfil == Perfil.DOCENTE) {
                    BotonPrestaAula(
                        texto = "Reservar",
                        tema = tema,
                        modifier = Modifier.weight(1f),
                        onClick = onReservar
                    )
                }
                if (perfil == Perfil.ENCARGADO_CRA && equipo.estado != EstadoEquipo.PRESTADO) {
                    BotonPrestaAula(
                        texto = if (equipo.estado == EstadoEquipo.MANTENCION) "Marcar disponible" else "Enviar a mantención",
                        tema = tema,
                        modifier = Modifier.weight(1f),
                        onClick = { vm.alternarMantencion(equipo.id) }
                    )
                }
                BotonContorno(
                    texto = "Volver",
                    modifier = Modifier.weight(1f),
                    onClick = onVolver
                )
            }
        }

        item { TituloSeccion("Historial de préstamos") }

        if (historial.isEmpty()) {
            item {
                TarjetaVidrio {
                    Text("Aún no hay préstamos para este equipo.", color = TextoSuave, fontSize = 14.sp)
                }
            }
        }

        items(historial, key = { it.id }) { p ->
            val color = colorEstadoPrestamo(p.estado)
            TarjetaVidrio(
                franja = Brush.verticalGradient(listOf(color, color.copy(alpha = 0.4f)))
            ) {
                Text(
                    "${p.docente} · ${p.curso}",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                EtiquetaEstado(p.estado.etiqueta, color)
                Spacer(Modifier.height(4.dp))
                LineaConIcono(Icons.Rounded.CalendarMonth, "${p.fecha} · ${p.bloque}")
                p.horaRetiro?.let { LineaConIcono(Icons.Rounded.ArrowUpward, "Retiro: $it") }
                p.horaDevolucion?.let { LineaConIcono(Icons.Rounded.ArrowDownward, "Devolución: $it") }
                p.estadoDevolucion?.let { LineaConIcono(Icons.Rounded.Search, "Al devolver: ${it.etiqueta}") }
                if (p.observaciones.isNotBlank()) {
                    LineaConIcono(Icons.Rounded.Edit, "Obs.: ${p.observaciones}")
                }
            }
        }
    }
}

@Composable
private fun Dato(etiqueta: String, valor: String) {
    Column {
        Text(etiqueta, color = TextoSuave, fontSize = 12.sp)
        Text(valor, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}
