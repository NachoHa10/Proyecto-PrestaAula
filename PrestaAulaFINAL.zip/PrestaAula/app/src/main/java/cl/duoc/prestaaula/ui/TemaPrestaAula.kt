@file:OptIn(ExperimentalMaterial3Api::class)

package cl.duoc.prestaaula.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cl.duoc.prestaaula.model.EstadoEquipo
import cl.duoc.prestaaula.model.EstadoPrestamo
import cl.duoc.prestaaula.model.Perfil

/* ───────────────────────── Colores y tema por perfil ───────────────────────── */

val FondoOscuro = listOf(Color(0xFF1A1040), Color(0xFF2D1B69), Color(0xFF4527A0))
val TextoSuave = Color(0xCCFFFFFF)
val SuperficieVidrio = Color(0x1FFFFFFF)
val BordeVidrio = Color(0x33FFFFFF)
val ColorDialogo = Color(0xFF2D1B69)
val ColorBotonDialogo = Color(0xFFB39DFF)

/** Tema de Material 3 oscuro: menús desplegables, diálogos y mensajes heredan los colores de la app. */
@Composable
fun PrestaAulaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF7C4DFF),
            onPrimary = Color.White,
            secondary = Color(0xFF536DFE),
            background = Color(0xFF1A1040),
            onBackground = Color.White,
            surface = ColorDialogo,
            onSurface = Color.White,
            onSurfaceVariant = TextoSuave,
            surfaceContainer = ColorDialogo,
            surfaceContainerHigh = ColorDialogo,
            surfaceContainerHighest = ColorDialogo,
            outline = Color(0x66FFFFFF)
        ),
        content = content
    )
}

/** Colores e icono (vectorial, nítido en cualquier pantalla) de cada perfil. */
data class TemaPerfil(
    val icono: ImageVector,
    val nombre: String,
    val colorA: Color,
    val colorB: Color
)

fun temaDePerfil(perfil: Perfil?): TemaPerfil = when (perfil) {
    Perfil.DOCENTE -> TemaPerfil(Icons.Rounded.School, "Docente", Color(0xFF7C4DFF), Color(0xFF536DFE))
    Perfil.ENCARGADO_CRA -> TemaPerfil(Icons.Rounded.MenuBook, "Encargado CRA", Color(0xFF00BFA5), Color(0xFF00B0FF))
    Perfil.JEFATURA -> TemaPerfil(Icons.Rounded.BarChart, "Jefatura", Color(0xFFFF6D00), Color(0xFFFF4081))
    null -> TemaPerfil(Icons.Rounded.School, "PrestaAula", Color(0xFF7C4DFF), Color(0xFF536DFE))
}

fun iconoDeTipo(tipo: String): ImageVector = when (tipo) {
    "Notebook" -> Icons.Rounded.Laptop
    "Tablet" -> Icons.Rounded.TabletAndroid
    "Proyector" -> Icons.Rounded.Slideshow
    "Cable HDMI" -> Icons.Rounded.Cable
    else -> Icons.Rounded.Inventory2
}

fun colorEstadoEquipo(e: EstadoEquipo): Color = when (e) {
    EstadoEquipo.DISPONIBLE -> Color(0xFF69F0AE)
    EstadoEquipo.PRESTADO -> Color(0xFFFFD740)
    EstadoEquipo.MANTENCION -> Color(0xFFFF8A80)
}

fun colorEstadoPrestamo(e: EstadoPrestamo): Color = when (e) {
    EstadoPrestamo.RESERVADO -> Color(0xFF40C4FF)
    EstadoPrestamo.RETIRADO -> Color(0xFFFFD740)
    EstadoPrestamo.DEVUELTO -> Color(0xFF69F0AE)
    EstadoPrestamo.CANCELADO -> Color(0xFFB0BEC5)
}

/* ───────────────────────── Fondo animado ───────────────────────── */

/** Fondo degradado con círculos flotantes. */
@Composable
fun FondoPrestaAula(
    tema: TemaPerfil,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val transicion = rememberInfiniteTransition(label = "fondoApp")
    val deriva by transicion.animateFloat(
        initialValue = -40f,
        targetValue = 40f,
        animationSpec = infiniteRepeatable(
            tween(5000, easing = FastOutSlowInEasing), RepeatMode.Reverse
        ),
        label = "derivaApp"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(FondoOscuro))
            .drawBehind {
                drawCircle(
                    color = tema.colorA.copy(alpha = 0.18f),
                    radius = size.width * 0.55f,
                    center = Offset(size.width * 0.95f, size.height * 0.08f + deriva)
                )
                drawCircle(
                    color = tema.colorB.copy(alpha = 0.14f),
                    radius = size.width * 0.45f,
                    center = Offset(size.width * 0.05f, size.height * 0.92f - deriva)
                )
            }
    ) {
        // Todo el texto sin color explícito se verá blanco sobre el fondo oscuro.
        CompositionLocalProvider(LocalContentColor provides Color.White) {
            content()
        }
    }
}

/* ───────────────────────── Componentes reutilizables ───────────────────────── */

/** Título de pantalla: círculo con icono (degradado del perfil) + título + subtítulo. */
@Composable
fun EncabezadoPantalla(
    icono: ImageVector,
    titulo: String,
    tema: TemaPerfil,
    subtitulo: String? = null
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconoCircular(
            icono = icono,
            tamano = 42.dp,
            fondo = Brush.linearGradient(listOf(tema.colorA, tema.colorB)),
            borde = Color(0x88FFFFFF)
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                titulo,
                color = Color.White,
                fontSize = 19.sp,
                fontWeight = FontWeight.ExtraBold
            )
            if (subtitulo != null) {
                Text(subtitulo, color = TextoSuave, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun TituloSeccion(texto: String) {
    Text(
        texto,
        color = Color.White,
        fontSize = 17.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 6.dp)
    )
}

/** Tarjeta translúcida (estilo "vidrio") con franja de color opcional a la izquierda. */
@Composable
fun TarjetaVidrio(
    modifier: Modifier = Modifier,
    franja: Brush? = null,
    relleno: Dp = 14.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val forma = RoundedCornerShape(20.dp)
    val interaccion = remember { MutableInteractionSource() }
    val presionado by interaccion.collectIsPressedAsState()
    val escala by animateFloatAsState(
        targetValue = if (presionado && onClick != null) 0.97f else 1f,
        label = "escalaTarjetaVidrio"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .scale(escala)
            .clip(forma)
            .background(SuperficieVidrio)
            .border(1.dp, BordeVidrio, forma)
            .then(
                if (onClick != null) Modifier.clickable(
                    interactionSource = interaccion,
                    indication = null,
                    onClick = onClick
                ) else Modifier
            )
            .height(IntrinsicSize.Min)
    ) {
        if (franja != null) {
            Box(
                Modifier
                    .width(6.dp)
                    .fillMaxHeight()
                    .background(franja)
            )
        }
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(relleno),
            verticalArrangement = Arrangement.spacedBy(3.dp),
            content = content
        )
    }
}

/** Botón principal con degradado del perfil. */
@Composable
fun BotonPrestaAula(
    texto: String,
    tema: TemaPerfil,
    modifier: Modifier = Modifier,
    habilitado: Boolean = true,
    onClick: () -> Unit
) {
    val interaccion = remember { MutableInteractionSource() }
    val presionado by interaccion.collectIsPressedAsState()
    val escala by animateFloatAsState(
        targetValue = if (presionado && habilitado) 0.96f else 1f,
        label = "escalaBotonApp"
    )

    Box(
        modifier = modifier
            .height(46.dp)
            .scale(escala)
            .alpha(if (habilitado) 1f else 0.4f)
            .clip(RoundedCornerShape(23.dp))
            .background(Brush.horizontalGradient(listOf(tema.colorA, tema.colorB)))
            .clickable(
                enabled = habilitado,
                interactionSource = interaccion,
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            texto,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
    }
}

/** Botón secundario con borde. */
@Composable
fun BotonContorno(
    texto: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(46.dp)
            .clip(RoundedCornerShape(23.dp))
            .border(1.dp, Color(0x88FFFFFF), RoundedCornerShape(23.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            texto,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
    }
}

/** Píldora de color para mostrar estados (Disponible, Prestado, etc.). [compacta] la reduce para tarjetas pequeñas. */
@Composable
fun EtiquetaEstado(texto: String, color: Color, compacta: Boolean = false) {
    Text(
        texto,
        color = color,
        fontSize = if (compacta) 10.5.sp else 12.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.18f))
            .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(50))
            .padding(
                horizontal = if (compacta) 8.dp else 10.dp,
                vertical = if (compacta) 2.dp else 4.dp
            )
    )
}

/** Chip de filtro con el estilo oscuro de la app. */
@Composable
fun ChipPrestaAula(
    texto: String,
    seleccionado: Boolean,
    acento: Color,
    modifier: Modifier = Modifier,
    habilitado: Boolean = true,
    onClick: () -> Unit
) {
    FilterChip(
        selected = seleccionado,
        onClick = onClick,
        enabled = habilitado,
        label = { Text(texto) },
        modifier = modifier,
        shape = RoundedCornerShape(50),
        colors = FilterChipDefaults.filterChipColors(
            containerColor = Color(0x14FFFFFF),
            labelColor = Color.White,
            selectedContainerColor = acento,
            selectedLabelColor = Color.White,
            disabledContainerColor = Color(0x0AFFFFFF),
            disabledLabelColor = Color(0x55FFFFFF)
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled = habilitado,
            selected = seleccionado,
            borderColor = Color(0x66FFFFFF),
            selectedBorderColor = Color.Transparent,
            disabledBorderColor = Color(0x22FFFFFF)
        )
    )
}

/** Colores de los campos de texto (idénticos a los del login). */
@Composable
fun coloresCampo(acento: Color) = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    cursorColor = Color.White,
    focusedBorderColor = acento,
    unfocusedBorderColor = Color(0x66FFFFFF),
    focusedLabelColor = Color.White,
    unfocusedLabelColor = Color(0xB3FFFFFF),
    focusedContainerColor = Color(0x14FFFFFF),
    unfocusedContainerColor = Color(0x14FFFFFF)
)
