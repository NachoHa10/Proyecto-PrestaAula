package cl.duoc.prestaaula.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Computer
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import cl.duoc.prestaaula.model.Perfil
import cl.duoc.prestaaula.ui.*
import cl.duoc.prestaaula.viewmodel.PrestaAulaViewModel
import kotlinx.coroutines.launch

// Rutas de la app. `{equipoId}` es un parámetro que viaja en la ruta (ej. detalle/NB-001).
object Rutas {
    const val LOGIN = "login"
    const val INVENTARIO = "inventario"
    const val DETALLE = "detalle/{equipoId}"
    const val RESERVAR = "reservar/{equipoId}"
    const val PRESTAMOS = "prestamos"
    const val REPORTES = "reportes"
}

private data class Tab(val ruta: String, val titulo: String, val icono: ImageVector)

/** Pestañas según el perfil de la cuenta con la que se inició sesión. */
private fun tabsPara(perfil: Perfil): List<Tab> = when (perfil) {
    Perfil.DOCENTE -> listOf(
        Tab(Rutas.INVENTARIO, "Equipos", Icons.Rounded.Computer),
        Tab(Rutas.PRESTAMOS, "Mis préstamos", Icons.Rounded.SwapHoriz)
    )
    Perfil.ENCARGADO_CRA -> listOf(
        Tab(Rutas.INVENTARIO, "Inventario", Icons.Rounded.Inventory2),
        Tab(Rutas.PRESTAMOS, "Préstamos", Icons.Rounded.SwapHoriz),
        Tab(Rutas.REPORTES, "Reportes", Icons.Rounded.BarChart)
    )
    Perfil.JEFATURA -> listOf(Tab(Rutas.REPORTES, "Reportes", Icons.Rounded.BarChart))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrestaAulaApp(vm: PrestaAulaViewModel) {
    // NavController: maneja la pila de pantallas. `remember` evita crearlo de nuevo en cada recomposición.
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val rutaActual = backStack?.destination?.route

    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    // Una sola función para mostrar mensajes (Snackbar). Se pasa a las pantallas como parámetro (state hoisting).
    val mostrarMensaje: (String) -> Unit = { scope.launch { snackbar.showSnackbar(it) } }

    val usuario = vm.usuario
    // Las pestañas dependen del perfil de la sesión. Sin sesión no hay pestañas.
    val tabs = usuario?.let { tabsPara(it.perfil) } ?: emptyList()

    // Si la sesión se cierra, volvemos al login y se limpia todo el historial de pantallas.
    LaunchedEffect(usuario) {
        if (usuario == null && rutaActual != null && rutaActual != Rutas.LOGIN) {
            nav.navigate(Rutas.LOGIN) { popUpTo(nav.graph.id) { inclusive = true } }
        }
    }

    // Cada perfil tiene su propio color e icono (docente morado, CRA verde, jefatura naranjo).
    val tema = temaDePerfil(usuario?.perfil)

    FondoPrestaAula(tema = tema) {
        Scaffold(
            containerColor = Color.Transparent,
            contentColor = Color.White,
            topBar = {
                if (usuario != null) {
                    TopAppBar(
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconoCircular(
                                    icono = tema.icono,
                                    tamano = 38.dp,
                                    fondo = Brush.linearGradient(listOf(tema.colorA, tema.colorB)),
                                    borde = Color(0x88FFFFFF)
                                )
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text("PrestaAula", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                                    Text("${usuario.nombre} · ${tema.nombre}", fontSize = 12.sp, color = TextoSuave)
                                }
                            }
                        },
                        actions = {
                            Text(
                                "Salir",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier
                                    .padding(end = 12.dp)
                                    .clip(RoundedCornerShape(50))
                                    .border(1.dp, Color(0x88FFFFFF), RoundedCornerShape(50))
                                    .clickable { vm.cerrarSesion() }
                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                            )
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color.Transparent,
                            titleContentColor = Color.White,
                            actionIconContentColor = Color.White
                        )
                    )
                }
            },
            bottomBar = {
                // La barra inferior solo aparece en las pantallas "raíz" (no en detalle ni reservar).
                if (usuario != null && tabs.any { it.ruta == rutaActual }) {
                    NavigationBar(
                        containerColor = Color(0x33000000),
                        contentColor = Color.White,
                        tonalElevation = 0.dp
                    ) {
                        tabs.forEach { t ->
                            NavigationBarItem(
                                selected = rutaActual == t.ruta,
                                // popUpTo + launchSingleTop + saveState/restoreState: cambiar de pestaña sin apilar
                                // pantallas repetidas y conservando el estado de cada una.
                                onClick = {
                                    nav.navigate(t.ruta) {
                                        popUpTo(tabs.first().ruta) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(imageVector = t.icono, contentDescription = t.titulo) },
                                label = { Text(t.titulo) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = Color.White,
                                    unselectedIconColor = Color(0xB3FFFFFF),
                                    unselectedTextColor = Color(0xB3FFFFFF),
                                    indicatorColor = tema.colorA
                                )
                            )
                        }
                    }
                }
            },
            snackbarHost = { SnackbarHost(snackbar) }
        ) { padding ->
            // NavHost: tabla de rutas -> pantallas. Parte en LOGIN.
            NavHost(
                navController = nav,
                startDestination = Rutas.LOGIN,
                modifier = Modifier.padding(padding)
            ) {
                composable(Rutas.LOGIN) {
                    LoginScreen(
                        onIngresar = { correo, clave, alTerminar ->
                            vm.iniciarSesion(correo, clave) { error ->
                                alTerminar(error)
                                if (error == null) {
                                    // El perfil sale de la cuenta: cada rol entra a su pantalla de inicio.
                                    vm.usuario?.let { u ->
                                        nav.navigate(tabsPara(u.perfil).first().ruta) {
                                            popUpTo(Rutas.LOGIN) { inclusive = true }
                                        }
                                    }
                                }
                            }
                        }
                    )
                }
                composable(Rutas.INVENTARIO) {
                    InventarioScreen(
                        vm = vm,
                        onEquipo = { id -> nav.navigate("detalle/$id") },
                        mostrarMensaje = mostrarMensaje
                    )
                }
                composable(
                    route = Rutas.DETALLE,
                    arguments = listOf(navArgument("equipoId") { type = NavType.StringType })
                ) { entry ->
                    // Se lee el ID que viaja en la ruta. Las pantallas reciben el ViewModel y lambdas de navegación
                    // (no conocen el NavController).
                    val id = entry.arguments?.getString("equipoId").orEmpty()
                    DetalleEquipoScreen(
                        vm = vm,
                        equipoId = id,
                        onReservar = { nav.navigate("reservar/$id") },
                        onVolver = { nav.popBackStack() }
                    )
                }
                composable(
                    route = Rutas.RESERVAR,
                    arguments = listOf(navArgument("equipoId") { type = NavType.StringType })
                ) { entry ->
                    val id = entry.arguments?.getString("equipoId").orEmpty()
                    ReservarScreen(
                        vm = vm,
                        equipoId = id,
                        // Al confirmar la reserva se va a "Mis préstamos" y se saca del historial la pantalla de reservar.
                        onListo = {
                            nav.navigate(Rutas.PRESTAMOS) {
                                popUpTo(Rutas.INVENTARIO)
                                launchSingleTop = true
                            }
                        },
                        mostrarMensaje = mostrarMensaje
                    )
                }
                composable(Rutas.PRESTAMOS) {
                    PrestamosScreen(vm = vm, mostrarMensaje = mostrarMensaje)
                }
                composable(Rutas.REPORTES) {
                    ReportesScreen(vm = vm)
                }
            }
        }
    }
}
