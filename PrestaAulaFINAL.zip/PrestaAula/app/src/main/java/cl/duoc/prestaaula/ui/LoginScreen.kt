package cl.duoc.prestaaula.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Pantalla 1: inicio de sesión. No se elige el perfil: el correo y la contraseña se validan contra
 * la tabla `usuarios` de Room y la cuenta ya trae su rol (docente, encargado CRA o jefatura),
 * que define qué pestañas y funciones ve el usuario.
 */
@Composable
fun LoginScreen(
    onIngresar: (correo: String, clave: String, alTerminar: (String?) -> Unit) -> Unit
) {
    // Estado local del formulario. rememberSaveable conserva lo escrito al rotar la pantalla.
    var correo by rememberSaveable { mutableStateOf("") }
    var clave by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var verClave by rememberSaveable { mutableStateOf(false) }

    val tema = temaDePerfil(null)
    val campos = coloresCampo(tema.colorB)

    // Animación infinita: el logo "late" entre escala 1.0 y 1.08. `visible` dispara la entrada animada una vez.
    val transicion = rememberInfiniteTransition(label = "pulsoLogin")
    val pulso by transicion.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse
        ),
        label = "pulso"
    )
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }

    // Cuentas de prueba (se toca una para rellenar los campos).
    val cuentas = listOf(
        Triple("Docente", "docente1@marcelapaz.cl", "docente123"),
        Triple("Encargado CRA", "cra@marcelapaz.cl", "cra123"),
        Triple("Jefatura (UTP / Adm. y Finanzas)", "jefatura@marcelapaz.cl", "jefatura123")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .imePadding()
            .padding(horizontal = 24.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 420.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn(tween(600)) + slideInVertically(tween(600)) { -it / 2 }
            ) {
                IconoCircular(
                    icono = tema.icono,
                    tamano = 84.dp,
                    modifier = Modifier.scale(pulso),
                    fondo = Brush.linearGradient(listOf(tema.colorA, tema.colorB)),
                    borde = Color(0x88FFFFFF)
                )
            }

            Spacer(Modifier.height(14.dp))

            AnimatedVisibility(visible = visible, enter = fadeIn(tween(600, delayMillis = 150))) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("PrestaAula", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("Colegio Marcela Paz", color = ColorBotonDialogo, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Préstamo de recursos tecnológicos y material didáctico",
                        color = TextoSuave,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(Modifier.height(22.dp))

            AnimatedVisibility(
                visible = visible,
                enter = fadeIn(tween(500, delayMillis = 300)) +
                        slideInVertically(tween(500, delayMillis = 300)) { it / 2 }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(SuperficieVidrio)
                        .border(1.dp, BordeVidrio, RoundedCornerShape(24.dp))
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Iniciar sesión", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)

                    OutlinedTextField(
                        value = correo,
                        onValueChange = { correo = it; error = null },
                        label = { Text("Correo") },
                        leadingIcon = { Icon(Icons.Rounded.Email, contentDescription = null, tint = Color(0xB3FFFFFF)) },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = campos,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = clave,
                        onValueChange = { clave = it; error = null },
                        label = { Text("Contraseña") },
                        leadingIcon = { Icon(Icons.Rounded.Lock, contentDescription = null, tint = Color(0xB3FFFFFF)) },
                        trailingIcon = {
                            Icon(
                                imageVector = if (verClave) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                contentDescription = "Mostrar u ocultar contraseña",
                                tint = Color(0xB3FFFFFF),
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .clickable { verClave = !verClave }
                                    .padding(8.dp)
                                    .size(22.dp)
                            )
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = campos,
                        visualTransformation =
                            if (verClave) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth()
                    )

                    error?.let {
                        Text(it, color = Color(0xFFFF8A80), fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }

                    BotonPrestaAula(
                        texto = "Ingresar",
                        tema = tema,
                        habilitado = correo.isNotBlank() && clave.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                        // La pantalla no valida nada: delega en onIngresar (state hoisting). El ViewModel responde por callback:
                        // null = éxito (AppNavigation navega), texto = mensaje de error que se muestra bajo los campos.
                        onClick = { onIngresar(correo, clave) { error = it } }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            AnimatedVisibility(visible = visible, enter = fadeIn(tween(500, delayMillis = 450))) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0x14FFFFFF))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        "Cuentas de prueba (toca una para usarla)",
                        color = TextoSuave,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    cuentas.forEach { (rol, mail, pass) ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { correo = mail; clave = pass; error = null }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(rol, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("$mail  ·  $pass", color = TextoSuave, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
