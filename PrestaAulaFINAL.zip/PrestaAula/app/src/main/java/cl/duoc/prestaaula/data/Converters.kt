package cl.duoc.prestaaula.data

import androidx.room.TypeConverter
import cl.duoc.prestaaula.model.*

/** Room guarda los enum como texto (su nombre). */
class Converters {
    @TypeConverter fun deEstadoEquipo(e: EstadoEquipo): String = e.name
    @TypeConverter fun aEstadoEquipo(s: String): EstadoEquipo = EstadoEquipo.valueOf(s)

    @TypeConverter fun dePerfil(p: Perfil): String = p.name
    @TypeConverter fun aPerfil(s: String): Perfil = Perfil.valueOf(s)

    @TypeConverter fun deEstadoPrestamo(e: EstadoPrestamo): String = e.name
    @TypeConverter fun aEstadoPrestamo(s: String): EstadoPrestamo = EstadoPrestamo.valueOf(s)

    // Este es nullable porque Prestamo.estadoDevolucion es opcional (null mientras no se devuelve).
    @TypeConverter fun deEstadoDevolucion(e: EstadoDevolucion?): String? = e?.name
    @TypeConverter fun aEstadoDevolucion(s: String?): EstadoDevolucion? = s?.let { EstadoDevolucion.valueOf(it) }
}
