package cl.duoc.prestaaula.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import cl.duoc.prestaaula.data.AppDatabase
import cl.duoc.prestaaula.model.*
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * Estado de la app respaldado por Room. Los DAO exponen Flow: cada vez que cambia una tabla,
 * `equipos` y `prestamos` se actualizan y la interfaz se recompone sola.
 *
 * FLUJO GENERAL:
 *   Pantalla (Compose) --evento--> ViewModel --suspend--> DAO --> SQLite
 *   SQLite --Flow--> ViewModel (actualiza el estado) --> Pantalla se recompone
 * La UI nunca toca la base de datos: todas las reglas de negocio viven aquí.
 */
class PrestaAulaViewModel(app: Application) : AndroidViewModel(app) {

    // Base de datos (singleton) y sus DAO. Solo el ViewModel habla con Room.
    private val db = AppDatabase.obtener(app)
    private val usuarioDao = db.usuarioDao()
    private val equipoDao = db.equipoDao()
    private val prestamoDao = db.prestamoDao()

    // ESTADO OBSERVABLE: cuando cambia uno de estos valores, Compose recompone las pantallas que lo leen.
    // `private set` = la UI solo puede leer; únicamente el ViewModel los modifica.
    // usuario == null significa "no hay sesión iniciada".
    var usuario by mutableStateOf<Usuario?>(null)
        private set
    var equipos by mutableStateOf<List<Equipo>>(emptyList())
        private set
    var prestamos by mutableStateOf<List<Prestamo>>(emptyList())
        private set

    // SEMILLA: inserta usuarios y equipos de ejemplo solo si las tablas están vacías (contar() == 0).
    // Es un Job guardado en una variable para poder esperarlo con `semilla.join()` en el login.
    private val semilla = viewModelScope.launch {
        if (usuarioDao.contar() == 0) {
            usuarioDao.insertarTodos(
                listOf(
                    Usuario(nombre = "Ana Torres", correo = "docente1@marcelapaz.cl", clave = "docente123", perfil = Perfil.DOCENTE),
                    Usuario(nombre = "Luis Rojas", correo = "docente2@marcelapaz.cl", clave = "docente123", perfil = Perfil.DOCENTE),
                    Usuario(nombre = "Carlos Soto", correo = "cra@marcelapaz.cl", clave = "cra123", perfil = Perfil.ENCARGADO_CRA),
                    Usuario(nombre = "María Pérez", correo = "jefatura@marcelapaz.cl", clave = "jefatura123", perfil = Perfil.JEFATURA)
                )
            )
        }
        if (equipoDao.contar() == 0) {
            equipoDao.insertarTodos(
                listOf(
                    Equipo("NB-001", "Notebook", "Lenovo"),
                    Equipo("NB-002", "Notebook", "HP"),
                    Equipo("TB-001", "Tablet", "Samsung"),
                    Equipo("PR-001", "Proyector", "Epson"),
                    Equipo("PR-002", "Proyector", "BenQ"),
                    Equipo("HD-001", "Cable HDMI", "Genérico")
                )
            )
        }
    }

    // Se suscribe a los Flow de Room. `collect` se ejecuta cada vez que la tabla cambia
    // y copia la lista nueva al estado de Compose (equipos / prestamos).
    init {
        viewModelScope.launch { equipoDao.observarTodos().collect { equipos = it } }
        viewModelScope.launch { prestamoDao.observarTodos().collect { prestamos = it } }
    }

    // ---------- Sesión ----------
    /**
     * Valida correo y contraseña contra la tabla usuarios. El perfil (docente, encargado CRA o jefatura)
     * lo define la cuenta guardada: no se elige a mano. [alTerminar] recibe un error, o null si fue exitoso.
     */
    fun iniciarSesion(correo: String, clave: String, alTerminar: (String?) -> Unit) {
        viewModelScope.launch {
            // Espera a que termine la semilla: evita un falso "credenciales incorrectas"
            // si alguien ingresa antes de que se inserten los usuarios la primera vez.
            semilla.join()
            // Se normaliza el correo (sin espacios y en minúsculas) antes de buscar.
            val u = usuarioDao.iniciarSesion(correo.trim().lowercase(), clave)
            if (u == null) {
                alTerminar("Correo o contraseña incorrectos")
            } else {
                usuario = u
                // Éxito: se guarda el usuario (esto cambia el estado y la UI reacciona) y se avisa con null = sin error.
                alTerminar(null)
            }
        }
    }

    fun cerrarSesion() {
        usuario = null
    }

    // ---------- Consultas ----------
    // REGLA CLAVE: un préstamo "activo" es el que ocupa el equipo: RESERVADO o RETIRADO.
    // Los CANCELADOS y DEVUELTOS ya no bloquean el horario.
    private fun activo(p: Prestamo) =
        p.estado == EstadoPrestamo.RESERVADO || p.estado == EstadoPrestamo.RETIRADO

    // ¿Se puede reservar este equipo en esa fecha y bloque?
    // No si el equipo no existe, está en mantención o ya tiene un préstamo activo en ese horario.
    fun equipoLibre(equipoId: String, fecha: String, bloque: String): Boolean {
        val eq = equipos.firstOrNull { it.id == equipoId } ?: return false
        if (eq.estado == EstadoEquipo.MANTENCION) return false
        return prestamos.none { activo(it) && it.equipoId == equipoId && it.fecha == fecha && it.bloque == bloque }
    }

    /** Reserva vigente (reservada o retirada) de un equipo en un bloque, o null si está libre. */
    fun reservaActiva(equipoId: String, fecha: String, bloque: String): Prestamo? =
        prestamos.firstOrNull { activo(it) && it.equipoId == equipoId && it.fecha == fecha && it.bloque == bloque }

    /** True si el equipo ya tiene alguna reserva vigente ese día (el calendario muestra un punto rojo). */
    fun tieneReservas(equipoId: String, fecha: String): Boolean =
        prestamos.any { activo(it) && it.equipoId == equipoId && it.fecha == fecha }

    // Evita que un mismo docente reserve dos equipos en el mismo bloque (no puede estar en dos lugares a la vez).
    fun docenteOcupado(docente: String, fecha: String, bloque: String): Boolean =
        prestamos.any { activo(it) && it.docente == docente && it.fecha == fecha && it.bloque == bloque }

    fun historialDe(equipoId: String): List<Prestamo> =
        prestamos.filter { it.equipoId == equipoId }.sortedByDescending { it.id }

    // ---------- Reservas y préstamos ----------
    /**
     * RESERVAR (flujo completo): valida en orden -> sesión, curso, equipo libre, docente libre.
     * Si algo falla devuelve el mensaje de error y NO guarda nada.
     * Si todo está bien inserta el préstamo (estado RESERVADO por defecto) y devuelve null.
     * Room avisa por Flow, `prestamos` se actualiza y todas las pantallas se refrescan solas.
     */
    fun reservar(equipoId: String, curso: String, fecha: String, bloque: String): String? {
        // El operador `?: return` corta la función con un mensaje si el valor es null.
        val u = usuario ?: return "Debes iniciar sesión"
        if (CURSOS.none { it.codigo == curso }) return "Elige un curso de la lista"
        if (!equipoLibre(equipoId, fecha, bloque)) return "El equipo no está disponible en ese bloque"
        if (docenteOcupado(u.nombre, fecha, bloque)) return "Ya tienes una reserva en ese bloque"
        // La inserción es una operación de base de datos: va en una corrutina (fuera del hilo principal).
        // El docente sale de la sesión (u.nombre), no se escribe a mano.
        viewModelScope.launch {
            prestamoDao.insertar(
                Prestamo(equipoId = equipoId, docente = u.nombre, curso = curso.trim(), fecha = fecha, bloque = bloque)
            )
        }
        return null
    }

    // `copy` crea una copia del data class con un campo cambiado (los data class son inmutables).
    fun cancelar(id: Int) = actualizarPrestamo(id) { it.copy(estado = EstadoPrestamo.CANCELADO) }

    // RETIRO (lo hace el CRA): solo si el equipo está DISPONIBLE.
    // Hace DOS cambios: préstamo -> RETIRADO (con hora) y equipo -> PRESTADO.
    fun confirmarRetiro(id: Int): String? {
        val p = prestamos.firstOrNull { it.id == id } ?: return "Préstamo no encontrado"
        val eq = equipos.firstOrNull { it.id == p.equipoId } ?: return "Equipo no encontrado"
        if (eq.estado != EstadoEquipo.DISPONIBLE) return "El equipo no está disponible (${eq.estado.etiqueta})"
        actualizarPrestamo(id) { it.copy(estado = EstadoPrestamo.RETIRADO, horaRetiro = ahora()) }
        cambiarEstadoEquipo(p.equipoId, EstadoEquipo.PRESTADO)
        return null
    }

    // DEVOLUCIÓN: guarda hora, estado y observaciones; el préstamo pasa a DEVUELTO.
    fun registrarDevolucion(id: Int, estado: EstadoDevolucion, observaciones: String) {
        val p = prestamos.firstOrNull { it.id == id } ?: return
        actualizarPrestamo(id) {
            it.copy(
                estado = EstadoPrestamo.DEVUELTO,
                horaDevolucion = ahora(),
                estadoDevolucion = estado,
                observaciones = observaciones.trim()
            )
        }
        // Si vuelve en buen estado queda DISPONIBLE; si trae daño o le falta un accesorio
        // se envía a MANTENCION (queda bloqueado y se cuenta como incidencia en Reportes).
        cambiarEstadoEquipo(
            p.equipoId,
            if (estado == EstadoDevolucion.BUEN_ESTADO) EstadoEquipo.DISPONIBLE else EstadoEquipo.MANTENCION
        )
    }

    // ---------- Inventario (encargado CRA) ----------
    // Valida campos vacíos e ID repetido (se normaliza a mayúsculas) antes de insertar.
    fun agregarEquipo(id: String, tipo: String, marca: String): String? {
        if (id.isBlank() || marca.isBlank()) return "Completa el ID y la marca"
        val idLimpio = id.trim().uppercase()
        if (equipos.any { it.id == idLimpio }) return "Ya existe un equipo con ese ID"
        viewModelScope.launch { equipoDao.insertar(Equipo(idLimpio, tipo, marca.trim())) }
        return null
    }

    // Botón del CRA: DISPONIBLE <-> MANTENCION. Un equipo PRESTADO no se puede tocar (no hace nada).
    fun alternarMantencion(id: String) {
        val eq = equipos.firstOrNull { it.id == id } ?: return
        when (eq.estado) {
            EstadoEquipo.DISPONIBLE -> cambiarEstadoEquipo(id, EstadoEquipo.MANTENCION)
            EstadoEquipo.MANTENCION -> cambiarEstadoEquipo(id, EstadoEquipo.DISPONIBLE)
            EstadoEquipo.PRESTADO -> Unit
        }
    }

    // ---------- Auxiliares ----------
    // Auxiliar: busca el préstamo, le aplica el cambio (lambda) y lo guarda con @Update.
    private fun actualizarPrestamo(id: Int, cambio: (Prestamo) -> Prestamo) {
        val p = prestamos.firstOrNull { it.id == id } ?: return
        viewModelScope.launch { prestamoDao.actualizar(cambio(p)) }
    }

    private fun cambiarEstadoEquipo(id: String, estado: EstadoEquipo) {
        val eq = equipos.firstOrNull { it.id == id } ?: return
        viewModelScope.launch { equipoDao.actualizar(eq.copy(estado = estado)) }
    }

    // Fecha y hora actual con formato dd/MM HH:mm para registrar retiros y devoluciones.
    private fun ahora(): String = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM HH:mm"))
}
