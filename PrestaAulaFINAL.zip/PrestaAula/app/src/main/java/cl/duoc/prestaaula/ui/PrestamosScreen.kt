package cl.duoc.prestaaula.ui

import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.ui.graphics.vector.ImageVector

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cl.duoc.prestaaula.model.EstadoDevolucion
import cl.duoc.prestaaula.model.EstadoPrestamo
import cl.duoc.prestaaula.model.Perfil
import cl.duoc.prestaaula.viewmodel.PrestaAulaViewModel

/**
 * Pantalla 5: préstamos. El docente ve los suyos; el encargado CRA ve todos.
 * Registrar retiro o devolución toma un par de pasos.
 */
@Composable
fun PrestamosScreen(vm: PrestaAulaViewModel, mostrarMensaje: (String) -> Unit) {
    val usuario = vm.usuario ?: return
    val esCra = usuario.perfil == Perfil.ENCARGADO_CRA
    val tema = temaDePerfil(usuario.perfil)
    // Si es distinto de null se muestra el diálogo de devolución para ese préstamo.
    var devolviendoId by rememberSaveable { mutableStateOf<Int?>(null) }

    // Docente: solo sus préstamos. CRA: todos. derivedStateOf recalcula solo cuando cambian los datos de los que depende.
    val lista by remember {
        derivedStateOf {
            vm.prestamos
                .filter { esCra || it.docente == usuario.nombre }
                .sortedByDescending { it.id }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Spacer(Modifier.height(6.dp))

        EncabezadoPantalla(
            icono = Icons.Rounded.SwapHoriz,
            titulo = if (esCra) "Préstamos del colegio" else "Mis préstamos",
            tema = tema,
            subtitulo = "${lista.size} registro(s)"
        )

        if (lista.isEmpty()) {
            TarjetaVidrio {
                Icon(
                    imageVector = Icons.Rounded.Inventory2,
                    contentDescription = null,
                    tint = TextoSuave,
                    modifier = Modifier.size(40.dp).align(Alignment.CenterHorizontally)
                )
                Text(
                    "No hay préstamos registrados.",
                    color = TextoSuave,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(lista, key = { it.id }) { p ->
                val equipo = vm.equipos.firstOrNull { it.id == p.equipoId }
                val color = colorEstadoPrestamo(p.estado)

                TarjetaVidrio(
                    franja = Brush.verticalGradient(listOf(color, color.copy(alpha = 0.4f)))
                ) {
                    Text(
                        "${equipo?.tipo.orEmpty()} ${equipo?.marca.orEmpty()} (${p.equipoId})",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    EtiquetaEstado(p.estado.etiqueta, color)
                    Spacer(Modifier.height(4.dp))

                    Linea(Icons.Rounded.Person, "Docente: ${p.docente} · Curso: ${p.curso}")
                    Linea(Icons.Rounded.CalendarMonth, "${p.fecha} · ${p.bloque}")
                    p.horaRetiro?.let { Linea(Icons.Rounded.ArrowUpward, "Retiro: $it") }
                    p.horaDevolucion?.let { Linea(Icons.Rounded.ArrowDownward, "Devolución: $it") }
                    p.estadoDevolucion?.let { Linea(Icons.Rounded.Search, "Al devolver: ${it.etiqueta}") }
                    if (p.observaciones.isNotBlank()) Linea(Icons.Rounded.Edit, "Obs.: ${p.observaciones}")

                    // Los botones dependen del estado:
                    // RESERVADO -> Confirmar retiro / Cancelar;  RETIRADO -> Registrar devolución;  el resto no tiene acciones.
                    when (p.estado) {
                        EstadoPrestamo.RESERVADO -> {
                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                BotonPrestaAula(
                                    texto = "Confirmar retiro",
                                    tema = tema,
                                    onClick = {
                                        val error = vm.confirmarRetiro(p.id)
                                        mostrarMensaje(error ?: "Retiro registrado")
                                    }
                                )
                                BotonContorno(
                                    texto = "Cancelar",
                                    onClick = { vm.cancelar(p.id) }
                                )
                            }
                        }
                        EstadoPrestamo.RETIRADO -> {
                            Spacer(Modifier.height(6.dp))
                            Row {
                                BotonPrestaAula(
                                    texto = "Registrar devolución",
                                    tema = tema,
                                    onClick = { devolviendoId = p.id }
                                )
                            }
                        }
                        else -> Unit
                    }
                }
            }
        }
    }

    // Diálogo de devolución: aparece mientras devolviendoId tenga un valor. Al guardar se limpia (vuelve a null).
    devolviendoId?.let { id ->
        DevolucionDialog(
            tema = tema,
            onCancelar = { devolviendoId = null },
            onGuardar = { estado, obs ->
                vm.registrarDevolucion(id, estado, obs)
                devolviendoId = null
                mostrarMensaje("Devolución registrada")
            }
        )
    }
}

@Composable
private fun Linea(icono: ImageVector, texto: String) {
    LineaConIcono(icono, texto)
}

@Composable
private fun DevolucionDialog(
    tema: TemaPerfil,
    onCancelar: () -> Unit,
    onGuardar: (EstadoDevolucion, String) -> Unit
) {
    var estadoIdx by rememberSaveable { mutableIntStateOf(0) }
    var obs by rememberSaveable { mutableStateOf("") }
    val estados = EstadoDevolucion.values()

    AlertDialog(
        onDismissRequest = onCancelar,
        containerColor = ColorDialogo,
        titleContentColor = Color.White,
        textContentColor = Color.White,
        shape = RoundedCornerShape(24.dp),
        title = { Text("Estado del equipo al devolver", fontWeight = FontWeight.ExtraBold) },
        text = {
            Column {
                estados.forEachIndexed { i, e ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = estadoIdx == i,
                            onClick = { estadoIdx = i },
                            colors = RadioButtonDefaults.colors(
                                selectedColor = tema.colorB,
                                unselectedColor = Color(0xB3FFFFFF)
                            )
                        )
                        Text(e.etiqueta, color = Color.White)
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = obs,
                    onValueChange = { obs = it },
                    label = { Text("Observaciones") },
                    shape = RoundedCornerShape(16.dp),
                    colors = coloresCampo(tema.colorB),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onGuardar(estados[estadoIdx], obs) },
                colors = ButtonDefaults.textButtonColors(contentColor = ColorBotonDialogo)
            ) { Text("Guardar", fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(
                onClick = onCancelar,
                colors = ButtonDefaults.textButtonColors(contentColor = Color(0xB3FFFFFF))
            ) { Text("Cancelar") }
        }
    )
}
