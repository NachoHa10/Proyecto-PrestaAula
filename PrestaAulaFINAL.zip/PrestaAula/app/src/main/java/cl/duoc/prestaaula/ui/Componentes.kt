package cl.duoc.prestaaula.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Column
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale

/* ───────────── Iconos ───────────── */

/** Icono vectorial dentro de un círculo. Al ser vectorial se ve nítido en cualquier densidad de pantalla. */
@Composable
fun IconoCircular(
    icono: ImageVector,
    modifier: Modifier = Modifier,
    tamano: Dp = 40.dp,
    fondo: Brush = SolidColor(Color(0x22FFFFFF)),
    borde: Color? = null
) {
    Box(
        modifier = modifier
            .size(tamano)
            .clip(CircleShape)
            .background(fondo)
            .then(if (borde != null) Modifier.border(1.5.dp, borde, CircleShape) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icono,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(tamano * 0.55f)
        )
    }
}

/** Línea de texto con un pequeño icono vectorial a la izquierda. */
@Composable
fun LineaConIcono(
    icono: ImageVector,
    texto: String,
    color: Color = TextoSuave,
    tamano: TextUnit = 13.sp
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = icono,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(15.dp)
        )
        Spacer(Modifier.width(6.dp))
        Text(texto, color = color, fontSize = tamano)
    }
}

/* ───────────── Menú desplegable ───────────── */

/**
 * Campo que se ve como un selector y abre un menú desplegable. No se puede escribir en él.
 * El contenido del menú lo define quien lo usa (lista simple, con encabezados, etc.).
 */
@Composable
fun CampoDesplegableBase(
    etiqueta: String,
    texto: String,
    acento: Color,
    modifier: Modifier = Modifier,
    // SLOT API: quien usa el componente decide qué mostrar dentro del menú (lista simple, grupos, etc.).
    // Recibe `cerrar` para poder cerrar el menú al elegir.
    menu: @Composable (cerrar: () -> Unit) -> Unit
) {
    var abierto by remember { mutableStateOf(false) }
    var anchoPx by remember { mutableIntStateOf(0) }
    val densidad = LocalDensity.current
    val forma = RoundedCornerShape(16.dp)

    Box(modifier = modifier.onSizeChanged { anchoPx = it.width }) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .clip(forma)
                .background(Color(0x14FFFFFF))
                .border(1.dp, if (abierto) acento else Color(0x66FFFFFF), forma)
                .clickable { abierto = true }
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(etiqueta, color = Color(0xB3FFFFFF), fontSize = 11.sp)
                Text(
                    texto,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Icon(
                imageVector = Icons.Rounded.KeyboardArrowDown,
                contentDescription = null,
                tint = Color.White
            )
        }

        DropdownMenu(
            expanded = abierto,
            onDismissRequest = { abierto = false },
            modifier = Modifier.width(with(densidad) { anchoPx.toDp() })
        ) {
            menu { abierto = false }
        }
    }
}

/** Desplegable de lista simple: el usuario elige una de las [opciones]. */
@Composable
fun CampoDesplegable(
    etiqueta: String,
    valor: String,
    opciones: List<String>,
    acento: Color,
    modifier: Modifier = Modifier,
    onSeleccion: (String) -> Unit
) {
    CampoDesplegableBase(etiqueta = etiqueta, texto = valor, acento = acento, modifier = modifier) { cerrar ->
        opciones.forEach { opcion ->
            DropdownMenuItem(
                text = {
                    Text(
                        opcion,
                        fontWeight = if (opcion == valor) FontWeight.Bold else FontWeight.Normal
                    )
                },
                onClick = {
                    onSeleccion(opcion)
                    cerrar()
                }
            )
        }
    }
}

/* ───────────── Calendario ───────────── */

/**
 * Calendario mensual real. Los días pasados y los fines de semana no se pueden elegir.
 * Un punto rojo indica que el equipo ya tiene reservas ese día.
 */
@Composable
fun CalendarioReserva(
    mes: YearMonth,
    hoy: LocalDate,
    seleccionado: LocalDate?,
    acento: Color,
    tieneReservas: (LocalDate) -> Boolean,
    onMesAnterior: () -> Unit,
    onMesSiguiente: () -> Unit,
    onSeleccionar: (LocalDate) -> Unit,
    modifier: Modifier = Modifier
) {
    // CÓMO SE ARMA EL CALENDARIO: celdas vacías hasta el primer día del mes + un día por cada día del mes.
    // `chunked(7)` las parte en semanas (filas de 7 columnas, la semana parte en lunes).
    val primerOffset = mes.atDay(1).dayOfWeek.value - 1 // lunes = 0
    val celdas = buildList<LocalDate?> {
        repeat(primerOffset) { add(null) }
        for (d in 1..mes.lengthOfMonth()) add(mes.atDay(d))
    }
    val semanas = celdas.chunked(7)
    val puedeRetroceder = mes.isAfter(YearMonth.from(hoy))
    val nombreMes = mes.month
        .getDisplayName(java.time.format.TextStyle.FULL, Locale.forLanguageTag("es-CL"))
        .replaceFirstChar { it.uppercase() }

    TarjetaVidrio(modifier = modifier) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            BotonFlecha("‹", habilitado = puedeRetroceder, onClick = onMesAnterior)
            Text(
                "$nombreMes ${mes.year}",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f)
            )
            BotonFlecha("›", habilitado = true, onClick = onMesSiguiente)
        }

        Spacer(Modifier.height(4.dp))

        Row(Modifier.fillMaxWidth()) {
            listOf("L", "M", "M", "J", "V", "S", "D").forEach { d ->
                Text(
                    d,
                    color = TextoSuave,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        semanas.forEach { semana ->
            Row(Modifier.fillMaxWidth()) {
                for (i in 0 until 7) {
                    val fecha = semana.getOrNull(i)
                    if (fecha == null) {
                        Spacer(Modifier.weight(1f).aspectRatio(1f))
                    } else {
                        CeldaDia(
                            fecha = fecha,
                            hoy = hoy,
                            seleccionada = fecha == seleccionado,
                            acento = acento,
                            hayReservas = tieneReservas(fecha),
                            onClick = { onSeleccionar(fecha) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BotonFlecha(simbolo: String, habilitado: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .alpha(if (habilitado) 1f else 0.3f)
            .clip(CircleShape)
            .border(1.dp, Color(0x66FFFFFF), CircleShape)
            .clickable(enabled = habilitado, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(simbolo, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun RowScope.CeldaDia(
    fecha: LocalDate,
    hoy: LocalDate,
    seleccionada: Boolean,
    acento: Color,
    hayReservas: Boolean,
    onClick: () -> Unit
) {
    val finDeSemana = fecha.dayOfWeek == DayOfWeek.SATURDAY || fecha.dayOfWeek == DayOfWeek.SUNDAY
    // No se puede elegir un día pasado ni sábado/domingo.
    val habilitado = !fecha.isBefore(hoy) && !finDeSemana
    val esHoy = fecha == hoy

    Box(
        modifier = Modifier
            .weight(1f)
            .aspectRatio(1f)
            .padding(2.dp)
            .clip(CircleShape)
            .then(
                if (seleccionada) Modifier.background(
                    Brush.linearGradient(listOf(acento, acento.copy(alpha = 0.7f)))
                ) else Modifier
            )
            .then(if (esHoy) Modifier.border(1.5.dp, Color(0xFFB39DFF), CircleShape) else Modifier)
            .clickable(enabled = habilitado, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "${fecha.dayOfMonth}",
            color = if (habilitado) Color.White else Color(0x55FFFFFF),
            fontSize = 14.sp,
            fontWeight = if (seleccionada) FontWeight.ExtraBold else FontWeight.Medium
        )
        if (hayReservas) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 3.dp)
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFF8A80))
            )
        }
    }
}
