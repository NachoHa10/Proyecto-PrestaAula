package cl.duoc.prestaaula.data

import androidx.room.*
import cl.duoc.prestaaula.model.Equipo
import kotlinx.coroutines.flow.Flow

@Dao
interface EquipoDao {
    @Query("SELECT * FROM equipos ORDER BY id")
    // Devuelve Flow (no es suspend): Room vuelve a emitir la lista cada vez que cambia la tabla.
    // Así la UI se actualiza sola, sin recargar a mano.
    fun observarTodos(): Flow<List<Equipo>>

    @Query("SELECT COUNT(*) FROM equipos")
    // Se usa para saber si hay que insertar los datos iniciales (la "semilla").
    suspend fun contar(): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertar(equipo: Equipo)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertarTodos(equipos: List<Equipo>)

    @Update
    // @Update busca la fila por su clave primaria (id) y reemplaza los demás campos.
    suspend fun actualizar(equipo: Equipo)
}
