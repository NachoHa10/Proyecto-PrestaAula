package cl.duoc.prestaaula.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import cl.duoc.prestaaula.model.Equipo
import cl.duoc.prestaaula.model.Prestamo
import cl.duoc.prestaaula.model.Usuario

// Declara la base de datos Room: qué tablas tiene (entities) y su versión.
// Cada @Entity del modelo se transforma en una tabla SQLite.
@Database(
    entities = [Usuario::class, Equipo::class, Prestamo::class],
    version = 1,
    exportSchema = false
)
// Enseña a Room a guardar los enum (ver Converters.kt).
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    // Room genera el código de cada DAO; aquí solo se declaran.
    abstract fun usuarioDao(): UsuarioDao
    abstract fun equipoDao(): EquipoDao
    abstract fun prestamoDao(): PrestamoDao

    companion object {
        // PATRÓN SINGLETON: una sola instancia de la base para toda la app.
        // @Volatile hace visible el valor entre hilos y `synchronized` evita que dos hilos
        // creen la base a la vez (doble verificación).
        @Volatile
        private var instancia: AppDatabase? = null

        // applicationContext evita filtrar una Activity. La base se guarda en el archivo "prestaaula.db".
        fun obtener(context: Context): AppDatabase =
            instancia ?: synchronized(this) {
                instancia ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "prestaaula.db"
                ).build().also { instancia = it }
            }
    }
}
