# PrestaAula (Kotlin + Jetpack Compose + Room)

Abrir en Android Studio: File > Open > seleccionar la carpeta PrestaAula (la que contiene settings.gradle.kts).
Esperar el Gradle Sync y ejecutar (Run) en un emulador o celular con Android 8.0 (API 26) o superior.

Ingreso: solo hay pantalla de Login. El perfil lo define la cuenta:
- Docente:        docente1@marcelapaz.cl / docente123   (tambien docente2@marcelapaz.cl)
- Encargado CRA:  cra@marcelapaz.cl / cra123
- Jefatura (UTP / Administracion y Finanzas): jefatura@marcelapaz.cl / jefatura123

Cursos del menu desplegable: editar CURSOS en model/Models.kt.
